﻿using Abp.Application.Services.Dto;

namespace kns.fms.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

