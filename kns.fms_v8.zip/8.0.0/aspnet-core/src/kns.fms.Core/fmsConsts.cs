﻿using kns.fms.Debugging;

namespace kns.fms
{
    public class fmsConsts
    {
        public const string LocalizationSourceName = "fms";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;


        /// <summary>
        /// Default pass phrase for SimpleStringCipher decrypt/encrypt operations
        /// </summary>
        public static readonly string DefaultPassPhrase =
            DebugHelper.IsDebug ? "gsKxGZ012HLL3MI5" : "4bc7938b6d9c453c9f63b8f7cc668f5f";
    }
}
