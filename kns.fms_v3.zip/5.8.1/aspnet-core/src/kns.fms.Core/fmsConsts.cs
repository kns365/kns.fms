﻿namespace kns.fms
{
    public class fmsConsts
    {
        public const string LocalizationSourceName = "fms";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
