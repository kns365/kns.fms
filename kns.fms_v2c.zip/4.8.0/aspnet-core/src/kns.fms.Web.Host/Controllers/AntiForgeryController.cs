using Microsoft.AspNetCore.Antiforgery;
using kns.fms.Controllers;

namespace kns.fms.Web.Host.Controllers
{
    public class AntiForgeryController : fmsControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
