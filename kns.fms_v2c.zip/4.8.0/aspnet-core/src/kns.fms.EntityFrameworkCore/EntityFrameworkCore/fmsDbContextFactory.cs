﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using kns.fms.Configuration;
using kns.fms.Web;

namespace kns.fms.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class fmsDbContextFactory : IDesignTimeDbContextFactory<fmsDbContext>
    {
        public fmsDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<fmsDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            fmsDbContextConfigurer.Configure(builder, configuration.GetConnectionString(fmsConsts.ConnectionStringName));

            return new fmsDbContext(builder.Options);
        }
    }
}
